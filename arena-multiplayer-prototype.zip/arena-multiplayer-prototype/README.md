# Arena Online — multiplayer 3D prototype

A small browser 3D tag-arena game using Three.js and Socket.IO. It is a non-weapon multiplayer prototype.

## Included
- Create room with a generated 5-character ID.
- Join the same room from other devices over the Internet.
- Real-time position updates, player avatars, score and tag action.
- Desktop WASD/mouse and basic mobile touch pads.
- Up to 8 players per room.
- Server validates that players are within tagging range and applies a short cooldown.

## Run locally
Install Node.js 18+ from https://nodejs.org/ then run:

```bash
npm install
npm start
```

Open http://localhost:3000. To test on another device on the same Wi-Fi, use `http://YOUR_COMPUTER_LAN_IP:3000` (firewall may need to allow port 3000).

## Publish online (free tier where available)
1. Create a GitHub account at https://github.com/ and verify your email.
2. Create a new repository, for example `arena-multiplayer-prototype`.
3. Upload the contents of this project. Keep `server.js`, `package.json`, `README.md`, and `public/` at the repository root.
4. Sign in to https://render.com/ and create **New + → Web Service**; connect your GitHub repository.
5. Settings: Runtime **Node**, Build Command `npm install`, Start Command `npm start`, choose Free instance if offered.
6. Deploy. The hosting service will provide a public HTTPS URL. Everyone opens that same URL, and joins using the room ID.
7. Test with at least two separate devices/browsers. A free host may sleep when idle and wake slowly.

## Important notes
- This is a prototype for casual testing, not a hardened production game.
- Room state is in server memory; server restarts end rooms.
- No accounts, matchmaking, chat, or persistent scores.
- Three.js is loaded from jsDelivr, so browsers need internet access.
- A public deployment is not created automatically by downloading this ZIP; it must be deployed to a hosting account.
