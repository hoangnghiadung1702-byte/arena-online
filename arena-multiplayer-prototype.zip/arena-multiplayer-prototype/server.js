const path = require("path");
const http = require("http");
const express = require("express");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: true }, pingInterval: 25000, pingTimeout: 20000 });
const PORT = process.env.PORT || 3000;
const rooms = new Map();
const MAX_PLAYERS = 8;
const ARENA_LIMIT = 24;
const TAG_RANGE = 2.4;
const TAG_COOLDOWN_MS = 1600;

app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true, rooms: rooms.size }));

function makeRoomId() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let id;
  do { id = Array.from({length:5}, () => chars[Math.floor(Math.random()*chars.length)]).join(""); }
  while (rooms.has(id));
  return id;
}
function safeName(value) {
  const name = String(value || "Player").trim().replace(/[<>]/g, "").slice(0,18);
  return name || "Player";
}
function publicPlayers(room) {
  return [...room.players.values()].map(p => ({
    id:p.id, name:p.name, x:p.x, y:1.65, z:p.z, yaw:p.yaw,
    hp:100, score:p.score, color:p.color, tags:p.tags
  }));
}
function sendRoomState(room) {
  io.to(room.id).emit("roomState", {roomId:room.id, hostId:room.hostId, players:publicPlayers(room)});
}
io.on("connection", socket => {
  socket.on("createRoom", ({name} = {}, reply = () => {}) => {
    if (socket.data.roomId) leaveRoom(socket);
    const id = makeRoomId();
    const room = {id, hostId:socket.id, players:new Map()};
    rooms.set(id, room);
    addPlayer(socket, room, name);
    reply({ok:true, roomId:id, playerId:socket.id});
    sendRoomState(room);
  });
  socket.on("joinRoom", ({roomId,name} = {}, reply = () => {}) => {
    const id = String(roomId || "").trim().toUpperCase();
    const room = rooms.get(id);
    if (!room) return reply({ok:false,error:"Không tìm thấy phòng. Hãy kiểm tra lại ID."});
    if (room.players.size >= MAX_PLAYERS) return reply({ok:false,error:`Phòng đã đủ ${MAX_PLAYERS} người.`});
    if (socket.data.roomId) leaveRoom(socket);
    addPlayer(socket, room, name);
    reply({ok:true, roomId:id, playerId:socket.id});
    sendRoomState(room);
    socket.to(id).emit("systemMessage", `${safeName(name)} đã tham gia phòng.`);
  });
  socket.on("move", data => {
    const room = rooms.get(socket.data.roomId);
    const p = room && room.players.get(socket.id);
    if (!p || !data) return;
    p.x = clampNum(data.x,-ARENA_LIMIT,ARENA_LIMIT,p.x);
    p.z = clampNum(data.z,-ARENA_LIMIT,ARENA_LIMIT,p.z);
    p.yaw = clampNum(data.yaw,-Math.PI*100,Math.PI*100,p.yaw);
    socket.to(room.id).emit("playerMoved",{id:p.id,x:p.x,y:1.65,z:p.z,yaw:p.yaw});
  });
  socket.on("tag", ({targetId} = {}) => {
    const room = rooms.get(socket.data.roomId);
    const actor = room && room.players.get(socket.id);
    const target = room && room.players.get(String(targetId || ""));
    if (!actor || !target || actor.id === target.id) return;
    const now = Date.now();
    if (now - actor.lastTagAt < TAG_COOLDOWN_MS) return;
    const distance = Math.hypot(actor.x-target.x, actor.z-target.z);
    if (distance > TAG_RANGE) return;
    actor.lastTagAt = now;
    actor.score += 1;
    actor.tags += 1;
    // A short, non-combat tag game: tagged player respawns at another point.
    target.x = randomSpawn();
    target.z = randomSpawn();
    io.to(room.id).emit("systemMessage", `${actor.name} chạm được ${target.name}!`);
    sendRoomState(room);
  });
  socket.on("disconnect", () => leaveRoom(socket));
});
function addPlayer(socket, room, name) {
  const colors = ["#58c4f6","#ff9f43","#9b8cff","#61d095","#ff6b81","#f4d35e","#ee82ee","#7bdff2"];
  room.players.set(socket.id,{
    id:socket.id,name:safeName(name),x:randomSpawn(),y:1.65,z:randomSpawn(),
    yaw:0,score:0,tags:0,lastTagAt:0,color:colors[room.players.size%colors.length]
  });
  socket.join(room.id); socket.data.roomId=room.id;
}
function leaveRoom(socket) {
  const id=socket.data.roomId;
  if(!id)return;
  const room=rooms.get(id);
  socket.leave(id); socket.data.roomId=null;
  if(!room)return;
  room.players.delete(socket.id);
  if(room.hostId===socket.id) room.hostId=room.players.keys().next().value||null;
  if(room.players.size===0) rooms.delete(id); else sendRoomState(room);
}
function randomSpawn(){return Math.round((Math.random()*28-14)*10)/10;}
function clampNum(value,min,max,fallback){
  const n=Number(value);return Number.isFinite(n)?Math.max(min,Math.min(max,n)):fallback;
}
server.listen(PORT,"0.0.0.0",()=>console.log(`Arena multiplayer listening on port ${PORT}`));
